package com.radware.vdirect.samples.calculator

import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.ws.rs.QueryParam;


import org.springframework.beans.factory.annotation.Autowired;


import com.radware.alteon.workflow.AdcWorkflowException;
import com.radware.alteon.workflow.impl.java.Devices;
import com.radware.alteon.sdk.containers.OpenstackContainer;
import com.radware.alteon.sdk.containers.SoftAdcInfo;
import com.radware.alteon.sdk.containers.SoftAdcInstance;
import com.radware.alteon.sdk.impl.resources.wrapped.WrappedAdcService;
import com.radware.alteon.sdk.impl.resources.wrapped.WrappedNetwork;
import com.radware.alteon.sdk.impl.resources.wrapped.WrappedVrrpPool;
import com.radware.alteon.sdk.resources.IPAddressPool;
import com.radware.alteon.sdk.resources.IslId;
import com.radware.alteon.sdk.rpm.AdcAcceptableType;
import com.radware.alteon.sdk.rpm.AdcInstanceRequest;
import com.radware.alteon.sdk.rpm.AdcService;
import com.radware.alteon.sdk.rpm.AdcServiceAction;
import com.radware.alteon.sdk.rpm.AdcServiceRequest;
import com.radware.alteon.workflow.impl.DeviceConnection;
import com.radware.alteon.workflow.impl.WorkflowAdaptor;
import com.radware.alteon.workflow.impl.java.Action;
import com.radware.alteon.workflow.impl.java.ChildWorkflow;
import com.radware.alteon.workflow.impl.java.ConfigurationTemplate;
import com.radware.alteon.workflow.impl.java.Param;
import com.radware.alteon.workflow.impl.java.State;
import com.radware.alteon.workflow.impl.java.Device;
import com.radware.alteon.workflow.impl.java.Workflow;
import com.radware.alteon.workflow.impl.java.Outputs;
import com.radware.logging.VDirectLogger;
import com.radware.vdirect.server.VDirectServerClient
import com.radware.vdirect.client.api.IAdcSessionBoundAccessManager;
import com.radware.vdirect.client.api.IAdcSessionBoundConfigurationTemplateManager;
import com.radware.vdirect.client.api.IAdcSessionBoundObjectFactory;
import com.radware.vdirect.client.sdk.IAdcSessionBoundContainerManager;
import com.radware.vdirect.client.sdk.IAdcSessionBoundResourceManager;
import com.radware.vdirect.client.sdk.IAdcSessionBoundResourcePoolManager;
import com.radware.vdirect.client.sdk.impl.InternalResourceManager;



/* The required @Workflow annotation marks this class as a workflow.
 * Note that workflow class definition MUST be the first class defined in the source file*/ 
@Workflow(
createAction='init',  /* Name of the optional create action */
deleteAction='teardown', /* Name of the optional delete action */
states = [ /* Required states used by the workflow */
	@State('ready'),
	@State('removed')],
properties = [
	/* These are the persistent properties of the workflow */
	@Param(name='value', type="int", prompt='Calculation result')
	])

class CalculatorkWorkflow {

	/* Injected variables */
	@Autowired WorkflowAdaptor workflow
	@Autowired VDirectLogger log
	
	/* The @Action annotation marks the method as an action */
	@Action(
	fromState="none", /* Optional allowed fromState */ 
	toState="ready", /* Optional final state for the action */
	visible=false /* Visible set to false hides the create action from end users */)
	void init () {
		workflow['result'] = 0
		log.info "Calculator ready"
	}


	@Action(fromState=["ready"], toState="ready")
	void set (@Param(name="newValue", type="int") int newValue) {
		workflow['value'] = newValue
		log.info "Value set to" + workflow['value']
	}
	
	@Action(fromState=["ready"], toState="ready")
	void add (@Param(name="addValue", type="int") int addValue) {
		workflow['value'] = workflow['value'] + addValue
		log.info "Value is" + workflow['value']
	}
	
	@Action(fromState=["ready"], toState="ready")
	void sub (@Param(name="subValue", type="int") int subValue) {
		workflow['value'] = workflow['value'] - subValue
		log.info "Value is" + workflow['value']
	}
	
	@Action(toState='removed')
	void teardown () {
		log.info "Tearing down"
	}
}
